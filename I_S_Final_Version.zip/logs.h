// Shani Sharon 212432967
// Itai Shaya 207033622

#pragma once

void AddLog(const char* text);