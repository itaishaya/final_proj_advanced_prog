// Shani Sharon 212432967
// Itai Shaya 207033622

#pragma once
#include "time.h"

time_t convertStringToTime(const char* date);